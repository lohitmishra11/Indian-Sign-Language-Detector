import cv2 as cv
import csv
import mediapipe as mp
from os import listdir
from os.path import isfile, join
from app import get_args, calc_landmark_list, pre_process_landmark

def train_using_images():

    args = get_args()
    setattr(args, "width", 128)
    setattr(args, "height", 128)
    use_static_image_mode = args.use_static_image_mode
    min_detection_confidence = args.min_detection_confidence
    min_tracking_confidence = args.min_tracking_confidence

    mp_hands = mp.solutions.hands

    hands = mp_hands.Hands(
        static_image_mode=use_static_image_mode,
        max_num_hands=2,
        min_detection_confidence=min_detection_confidence,
        min_tracking_confidence=min_tracking_confidence,
    )

    csv_path = 'model/keypoint_classifier/keypoint.csv'
    training_images_path = 'model/training_images/'
    img_categories = listdir(training_images_path)
    for number, category in enumerate(img_categories):
        images = listdir(join(training_images_path, category))
        for img in images:
            image = cv.imread(join(training_images_path, category, img))
            # image = cv.flip(image, 1)
            image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
            results = hands.process(image)
            if results.multi_hand_landmarks is not None:
                for hand_landmarks in results.multi_hand_landmarks:
                    landmark_list = calc_landmark_list(image, hand_landmarks)
                    pre_processed_landmark_list = pre_process_landmark(landmark_list)
                    with open(csv_path, 'a', newline="") as f:
                        writer = csv.writer(f)
                        writer.writerow([number, *pre_processed_landmark_list])
    print("Image Logging complete!")

train_using_images()
